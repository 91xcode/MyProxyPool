# ProxyPool

## 使用方法
<br>

#### 安装依赖

pip install -r requirements.txt
<br>

#### 打开代理池和API

python run.py
<br>

访问127.0.0.1:5555/random 获取ip

<br>

修改自

https://github.com/Germey/ProxyPool 
https://github.com/Python3WebSpider/ProxyPool



抓取proxy改成异步, 优化了测试proxy异步代码 

提高了代理可用性







